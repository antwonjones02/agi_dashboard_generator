#!/usr/bin/env python3
"""
AGI Dashboard Generator - Data Extraction and Analysis

This module provides functionality to extract data from various report formats
(Excel, CSV, PDF) and analyze it to identify patterns and insights, with a focus
on operational KPIs and learning/development metrics.
"""

import os
import pandas as pd
import numpy as np
import logging
import PyPDF2
from pathlib import Path
import re

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('AGI-Dashboard-Generator')

class DataExtractor:
    """
    Extract data from various report formats.
    """
    
    def __init__(self):
        """Initialize the data extractor."""
        logger.info("Data extractor initialized")
    
    def extract_data(self, file_path, file_type):
        """
        Extract data from a report file.
        
        Args:
            file_path: Path to the report file
            file_type: Type of report file ('excel', 'csv', 'pdf')
            
        Returns:
            dict: Extracted data and metadata
        """
        logger.info(f"Extracting data from {file_type} file: {file_path}")
        
        if file_type == 'excel':
            return self._extract_from_excel(file_path)
        elif file_type == 'csv':
            return self._extract_from_csv(file_path)
        elif file_type == 'pdf':
            return self._extract_from_pdf(file_path)
        else:
            logger.error(f"Unsupported file type: {file_type}")
            return None
    
    def _extract_from_excel(self, file_path):
        """
        Extract data from an Excel file.
        
        Args:
            file_path: Path to the Excel file
            
        Returns:
            dict: Extracted data and metadata
        """
        try:
            # Get the Excel file name without extension
            file_name = os.path.basename(file_path)
            file_name_without_ext = os.path.splitext(file_name)[0]
            
            # Read all sheets from the Excel file
            excel_data = pd.read_excel(file_path, sheet_name=None)
            
            # Process each sheet
            processed_data = {}
            for sheet_name, df in excel_data.items():
                # Clean the dataframe
                df = self._clean_dataframe(df)
                
                # Store the processed dataframe
                processed_data[sheet_name] = df
            
            # Create metadata
            metadata = {
                'file_name': file_name,
                'file_type': 'excel',
                'sheet_count': len(excel_data),
                'sheet_names': list(excel_data.keys()),
                'row_counts': {sheet: df.shape[0] for sheet, df in processed_data.items()},
                'column_counts': {sheet: df.shape[1] for sheet, df in processed_data.items()},
                'column_names': {sheet: list(df.columns) for sheet, df in processed_data.items()}
            }
            
            return {
                'data': processed_data,
                'metadata': metadata
            }
        
        except Exception as e:
            logger.error(f"Error extracting data from Excel file: {e}")
            return None
    
    def _extract_from_csv(self, file_path):
        """
        Extract data from a CSV file.
        
        Args:
            file_path: Path to the CSV file
            
        Returns:
            dict: Extracted data and metadata
        """
        try:
            # Get the CSV file name without extension
            file_name = os.path.basename(file_path)
            file_name_without_ext = os.path.splitext(file_name)[0]
            
            # Read the CSV file
            df = pd.read_csv(file_path)
            
            # Clean the dataframe
            df = self._clean_dataframe(df)
            
            # Create metadata
            metadata = {
                'file_name': file_name,
                'file_type': 'csv',
                'row_count': df.shape[0],
                'column_count': df.shape[1],
                'column_names': list(df.columns)
            }
            
            return {
                'data': {file_name_without_ext: df},
                'metadata': metadata
            }
        
        except Exception as e:
            logger.error(f"Error extracting data from CSV file: {e}")
            return None
    
    def _extract_from_pdf(self, file_path):
        """
        Extract data from a PDF file.
        
        Args:
            file_path: Path to the PDF file
            
        Returns:
            dict: Extracted data and metadata
        """
        try:
            # Get the PDF file name without extension
            file_name = os.path.basename(file_path)
            file_name_without_ext = os.path.splitext(file_name)[0]
            
            # Open the PDF file
            with open(file_path, 'rb') as file:
                # Create a PDF reader object
                pdf_reader = PyPDF2.PdfReader(file)
                
                # Get the number of pages
                num_pages = len(pdf_reader.pages)
                
                # Extract text from each page
                text_content = []
                for page_num in range(num_pages):
                    page = pdf_reader.pages[page_num]
                    text_content.append(page.extract_text())
                
                # Join all text content
                full_text = '\n'.join(text_content)
                
                # Try to extract tables from the text
                tables = self._extract_tables_from_text(full_text)
                
                # Create metadata
                metadata = {
                    'file_name': file_name,
                    'file_type': 'pdf',
                    'page_count': num_pages,
                    'table_count': len(tables)
                }
                
                return {
                    'data': {
                        'text': full_text,
                        'tables': tables
                    },
                    'metadata': metadata
                }
        
        except Exception as e:
            logger.error(f"Error extracting data from PDF file: {e}")
            return None
    
    def _extract_tables_from_text(self, text):
        """
        Attempt to extract tables from text.
        
        Args:
            text: Text content
            
        Returns:
            list: List of extracted tables as dataframes
        """
        # This is a simplified implementation
        # In a real-world scenario, you would use more sophisticated methods
        # such as tabula-py or other PDF table extraction libraries
        
        tables = []
        
        # Split the text into lines
        lines = text.split('\n')
        
        # Look for potential table markers
        table_start_indices = []
        table_end_indices = []
        
        for i, line in enumerate(lines):
            # Check for lines that might indicate the start of a table
            # (e.g., lines with multiple commas or tabs)
            if line.count(',') >= 3 or line.count('\t') >= 3:
                if not table_start_indices or table_start_indices[-1] < table_end_indices[-1]:
                    table_start_indices.append(i)
            
            # Check for lines that might indicate the end of a table
            # (e.g., empty lines after a potential table)
            if line.strip() == '' and table_start_indices and (not table_end_indices or table_start_indices[-1] > table_end_indices[-1]):
                table_end_indices.append(i)
        
        # Ensure we have matching start and end indices
        if len(table_start_indices) > len(table_end_indices):
            table_end_indices.append(len(lines))
        
        # Extract tables
        for start, end in zip(table_start_indices, table_end_indices):
            table_lines = lines[start:end]
            
            # Skip if too few lines
            if len(table_lines) < 2:
                continue
            
            # Try to determine the delimiter
            first_line = table_lines[0]
            if ',' in first_line:
                delimiter = ','
            elif '\t' in first_line:
                delimiter = '\t'
            else:
                # Try to split by whitespace
                delimiter = None
            
            # Create a dataframe from the table lines
            try:
                if delimiter:
                    # Create a CSV-like string
                    csv_string = '\n'.join(table_lines)
                    df = pd.read_csv(pd.StringIO(csv_string), delimiter=delimiter)
                else:
                    # Try to split by whitespace
                    data = []
                    for line in table_lines:
                        data.append(line.split())
                    
                    # Use the first row as header
                    header = data[0]
                    rows = data[1:]
                    
                    # Create a dataframe
                    df = pd.DataFrame(rows, columns=header)
                
                # Clean the dataframe
                df = self._clean_dataframe(df)
                
                tables.append(df)
            
            except Exception as e:
                logger.warning(f"Failed to extract table: {e}")
        
        return tables
    
    def _clean_dataframe(self, df):
        """
        Clean a dataframe by handling missing values, removing duplicates, etc.
        
        Args:
            df: Pandas dataframe
            
        Returns:
            df: Cleaned dataframe
        """
        # Make a copy to avoid modifying the original
        df = df.copy()
        
        # Remove completely empty rows and columns
        df.dropna(how='all', inplace=True)
        df.dropna(axis=1, how='all', inplace=True)
        
        # Remove duplicate rows
        df.drop_duplicates(inplace=True)
        
        # Clean column names
        df.columns = [str(col).strip() for col in df.columns]
        
        return df


class DataAnalyzer:
    """
    Analyze data to identify patterns and insights, with a focus on
    operational KPIs and learning/development metrics.
    """
    
    def __init__(self):
        """Initialize the data analyzer."""
        logger.info("Data analyzer initialized")
        
        # Define KPI categories and related keywords
        self.kpi_categories = {
            'learning_completion': [
                'completion', 'progress', 'finished', 'graduated', 'certified',
                'pass rate', 'completion rate', 'graduation rate', 'certification rate'
            ],
            'learning_engagement': [
                'engagement', 'participation', 'active', 'attendance', 'session',
                'login', 'access', 'view', 'download', 'time spent', 'duration'
            ],
            'learning_performance': [
                'score', 'grade', 'performance', 'assessment', 'test', 'exam',
                'quiz', 'evaluation', 'rating', 'ranking', 'percentile'
            ],
            'operational_efficiency': [
                'efficiency', 'productivity', 'output', 'throughput', 'turnaround',
                'cycle time', 'processing time', 'response time', 'lead time'
            ],
            'training_cost': [
                'cost', 'expense', 'budget', 'spending', 'investment',
                'roi', 'return', 'value', 'benefit', 'saving'
            ]
        }
    
    def analyze_data(self, extracted_data):
        """
        Analyze extracted data to identify patterns and insights.
        
        Args:
            extracted_data: Dict containing extracted data and metadata
            
        Returns:
            dict: Analysis results
        """
        if not extracted_data:
            logger.error("No data to analyze")
            return None
        
        logger.info(f"Analyzing data from {extracted_data['metadata']['file_name']}")
        
        file_type = extracted_data['metadata']['file_type']
        
        if file_type in ['excel', 'csv']:
            return self._analyze_tabular_data(extracted_data)
        elif file_type == 'pdf':
            return self._analyze_pdf_data(extracted_data)
        else:
            logger.error(f"Unsupported file type for analysis: {file_type}")
            return None
    
    def _analyze_tabular_data(self, extracted_data):
        """
        Analyze tabular data (Excel, CSV).
        
        Args:
            extracted_data: Dict containing extracted data and metadata
            
        Returns:
            dict: Analysis results
        """
        analysis_results = {
            'file_name': extracted_data['metadata']['file_name'],
            'file_type': extracted_data['metadata']['file_type'],
            'summary': {},
            'kpi_metrics': {},
            'correlations': {},
            'trends': {},
            'insights': []
        }
        
        # Process each dataframe
        for sheet_name, df in extracted_data['data'].items():
            # Skip if dataframe is empty
            if df.empty:
                continue
            
            # Create a summary for this sheet/dataframe
            summary = self._create_data_summary(df)
            analysis_results['summary'][sheet_name] = summary
            
            # Identify KPI metrics
            kpi_metrics = self._identify_kpi_metrics(df)
            if kpi_metrics:
                analysis_results['kpi_metrics'][sheet_name] = kpi_metrics
            
            # Calculate correlations between numeric columns
            correlations = self._calculate_correlations(df)
            if correlations is not None:
                analysis_results['correlations'][sheet_name] = correlations
            
            # Identify trends in time series data
            trends = self._identify_trends(df)
            if trends:
                analysis_results['trends'][sheet_name] = trends
            
            # Generate insights
            insights = self._generate_insights(df, sheet_name, kpi_metrics, correlations, trends)
            if insights:
                analysis_results['insights'].extend(insights)
        
        return analysis_results
    
    def _analyze_pdf_data(self, extracted_data):
        """
        Analyze PDF data.
        
        Args:
            extracted_data: Dict containing extracted data and metadata
            
        Returns:
            dict: Analysis results
        """
        analysis_results = {
            'file_name': extracted_data['metadata']['file_name'],
            'file_type': extracted_data['metadata']['file_type'],
            'summary': {},
            'kpi_metrics': {},
            'key_terms': {},
            'insights': []
        }
        
        # Analyze text content
        text = extracted_data['data']['text']
        
        # Extract key terms related to KPIs
        key_terms = self._extract_key_terms(text)
        analysis_results['key_terms'] = key_terms
        
        # Analyze tables if available
        tables = extracted_data['data']['tables']
        
        for i, df in enumerate(tables):
            table_name = f"Table_{i+1}"
            
            # Create a summary for this table
            summary = self._create_data_summary(df)
            analysis_results['summary'][table_name] = summary
            
            # Identify KPI metrics
            kpi_metrics = self._identify_kpi_metrics(df)
            if kpi_metrics:
                analysis_results['kpi_metrics'][table_name] = kpi_metrics
            
            # Generate insights
            insights = self._generate_insights(df, table_name, kpi_metrics, None, None)
            if insights:
                analysis_results['insights'].extend(insights)
        
        return analysis_results
    
    def _create_data_summary(self, df):
        """
        Create a summary of the dataframe.
        
        Args:
            df: Pandas dataframe
            
        Returns:
            dict: Summary statistics
        """
        summary = {
            'row_count': df.shape[0],
            'column_count': df.shape[1],
            'column_names': list(df.columns),
            'column_types': {},
            'numeric_stats': {},
            'categorical_stats': {},
            'date_stats': {}
        }
        
        # Analyze each column
        for col in df.columns:
            # Skip if column is empty
            if df[col].isna().all():
                continue
            
            # Determine column type
            if pd.api.types.is_numeric_dtype(df[col]):
                col_type = 'numeric'
                
                # Calculate statistics for numeric columns
                stats = {
                    'min': float(df[col].min()) if not pd.isna(df[col].min()) else None,
                    'max': float(df[col].max()) if not pd.isna(df[col].max()) else None,
                    'mean': float(df[col].mean()) if not pd.isna(df[col].mean()) else None,
                    'median': float(df[col].median()) if not pd.isna(df[col].median()) else None,
                    'std': float(df[col].std()) if not pd.isna(df[col].std()) else None
                }
                
                summary['numeric_stats'][col] = stats
            
            elif pd.api.types.is_datetime64_dtype(df[col]) or self._is_date_column(df[col]):
                col_type = 'date'
                
                # Convert to datetime if not already
                if not pd.api.types.is_datetime64_dtype(df[col]):
                    try:
                        date_series = pd.to_datetime(df[col])
                    except:
                        date_series = df[col]
                else:
                    date_series = df[col]
                
                # Calculate statistics for date columns
                stats = {
                    'min': date_series.min().strftime('%Y-%m-%d') if not pd.isna(date_series.min()) else None,
                    'max': date_series.max().strftime('%Y-%m-%d') if not pd.isna(date_series.max()) else None,
                    'range_days': (date_series.max() - date_series.min()).days if not pd.isna(date_series.min()) and not pd.isna(date_series.max()) else None
                }
                
                summary['date_stats'][col] = stats
            
            else:
                col_type = 'categorical'
                
                # Calculate statistics for categorical columns
                value_counts = df[col].value_counts()
                
                stats = {
                    'unique_values': int(df[col].nunique()),
                    'most_common': value_counts.index[0] if not value_counts.empty else None,
                    'most_common_count': int(value_counts.iloc[0]) if not value_counts.empty else None
                }
                
                summary['categorical_stats'][col] = stats
            
            summary['column_types'][col] = col_type
        
        return summary
    
    def _is_date_column(self, series):
        """
        Check if a series contains date values.
        
        Args:
            series: Pandas series
            
        Returns:
            bool: True if the series contains date values, False otherwise
        """
        # Try to convert to datetime
        try:
            pd.to_datetime(series)
            return True
        except:
            return False
    
    def _identify_kpi_metrics(self, df):
        """
        Identify KPI metrics in the dataframe.
        
        Args:
            df: Pandas dataframe
            
        Returns:
            dict: KPI metrics
        """
        kpi_metrics = {}
        
        # Check each column for KPI-related keywords
        for col in df.columns:
            col_lower = col.lower()
            
            # Check if the column name matches any KPI category
            for category, keywords in self.kpi_categories.items():
                if any(keyword.lower() in col_lower for keyword in keywords):
                    # If the column is numeric, calculate KPI statistics
                    if pd.api.types.is_numeric_dtype(df[col]):
                        kpi_metrics[col] = {
                            'category': category,
                            'min': float(df[col].min()) if not pd.isna(df[col].min()) else None,
                            'max': float(df[col].max()) if not pd.isna(df[col].max()) else None,
                            'mean': float(df[col].mean()) if not pd.isna(df[col].mean()) else None,
                            'median': float(df[col].median()) if not pd.isna(df[col].median()) else None,
                            'std': float(df[col].std()) if not pd.isna(df[col].std()) else None
                        }
                    else:
                        # For non-numeric columns, just record the category
                        kpi_metrics[col] = {
                            'category': category
                        }
                    
                    # Break after finding the first matching category
                    break
        
        return kpi_metrics
    
    def _calculate_correlations(self, df):
        """
        Calculate correlations between numeric columns.
        
        Args:
            df: Pandas dataframe
            
        Returns:
            dict: Correlation matrix
        """
        # Get numeric columns
        numeric_cols = df.select_dtypes(include=['number']).columns
        
        # Skip if less than 2 numeric columns
        if len(numeric_cols) < 2:
            return None
        
        # Calculate correlation matrix
        corr_matrix = df[numeric_cols].corr().round(2)
        
        # Convert to dictionary
        corr_dict = {}
        for col1 in corr_matrix.columns:
            corr_dict[col1] = {}
            for col2 in corr_matrix.columns:
                if col1 != col2:
                    corr_dict[col1][col2] = float(corr_matrix.loc[col1, col2])
        
        return corr_dict
    
    def _identify_trends(self, df):
        """
        Identify trends in time series data.
        
        Args:
            df: Pandas dataframe
            
        Returns:
            dict: Trends
        """
        trends = {}
        
        # Check if the dataframe has date columns
        date_cols = []
        for col in df.columns:
            if pd.api.types.is_datetime64_dtype(df[col]) or self._is_date_column(df[col]):
                date_cols.append(col)
        
        # Skip if no date columns
        if not date_cols:
            return trends
        
        # Get numeric columns
        numeric_cols = df.select_dtypes(include=['number']).columns
        
        # Skip if no numeric columns
        if len(numeric_cols) == 0:
            return trends
        
        # Analyze trends for each date column and numeric column combination
        for date_col in date_cols:
            # Convert to datetime if not already
            if not pd.api.types.is_datetime64_dtype(df[date_col]):
                try:
                    date_series = pd.to_datetime(df[date_col])
                except:
                    continue
            else:
                date_series = df[date_col]
            
            # Create a copy of the dataframe with the date column as index
            trend_df = df.copy()
            trend_df['_date'] = date_series
            trend_df.set_index('_date', inplace=True)
            
            # Sort by date
            trend_df.sort_index(inplace=True)
            
            # Analyze trends for each numeric column
            for num_col in numeric_cols:
                # Skip if column has too many missing values
                if trend_df[num_col].isna().sum() > len(trend_df) * 0.5:
                    continue
                
                # Calculate trend
                try:
                    # Use simple linear regression to determine trend
                    x = np.arange(len(trend_df))
                    y = trend_df[num_col].values
                    
                    # Skip if not enough data points
                    if len(y) < 3:
                        continue
                    
                    # Remove NaN values
                    mask = ~np.isnan(y)
                    x = x[mask]
                    y = y[mask]
                    
                    # Skip if not enough data points after removing NaNs
                    if len(y) < 3:
                        continue
                    
                    # Calculate trend
                    slope, intercept = np.polyfit(x, y, 1)
                    
                    # Determine trend direction
                    if slope > 0.01:
                        trend = 'increasing'
                    elif slope < -0.01:
                        trend = 'decreasing'
                    else:
                        trend = 'stable'
                    
                    # Calculate percent change
                    start_value = y[0]
                    end_value = y[-1]
                    
                    if start_value != 0:
                        percent_change = ((end_value - start_value) / abs(start_value)) * 100
                    else:
                        percent_change = 0
                    
                    # Store trend information
                    trends[f"{date_col}_{num_col}"] = {
                        'date_column': date_col,
                        'metric_column': num_col,
                        'trend': trend,
                        'slope': float(slope),
                        'start_value': float(start_value),
                        'end_value': float(end_value),
                        'percent_change': float(percent_change)
                    }
                
                except Exception as e:
                    logger.warning(f"Error calculating trend for {num_col}: {e}")
        
        return trends
    
    def _extract_key_terms(self, text):
        """
        Extract key terms related to KPIs from text.
        
        Args:
            text: Text content
            
        Returns:
            dict: Key terms
        """
        key_terms = {}
        
        # Check for each KPI category
        for category, keywords in self.kpi_categories.items():
            category_terms = []
            
            for keyword in keywords:
                # Look for the keyword in the text
                pattern = r'\b' + re.escape(keyword) + r'[:\s]([^.]*)'
                matches = re.findall(pattern, text, re.IGNORECASE)
                
                for match in matches:
                    # Clean up the match
                    term = match.strip()
                    if term and len(term) > 3:
                        category_terms.append(f"{keyword}: {term}")
            
            if category_terms:
                key_terms[category] = category_terms
        
        return key_terms
    
    def _generate_insights(self, df, sheet_name, kpi_metrics, correlations, trends):
        """
        Generate insights from the analyzed data.
        
        Args:
            df: Pandas dataframe
            sheet_name: Name of the sheet or table
            kpi_metrics: KPI metrics
            correlations: Correlation matrix
            trends: Trends
            
        Returns:
            list: Insights
        """
        insights = []
        
        # Generate insights from KPI metrics
        if kpi_metrics:
            for col, metrics in kpi_metrics.items():
                category = metrics.get('category')
                
                if category == 'learning_completion':
                    if 'mean' in metrics:
                        insights.append({
                            'type': 'kpi',
                            'category': category,
                            'source': f"{sheet_name} - {col}",
                            'description': f"Average completion rate is {metrics['mean']:.2f}%"
                        })
                
                elif category == 'learning_engagement':
                    if 'mean' in metrics:
                        insights.append({
                            'type': 'kpi',
                            'category': category,
                            'source': f"{sheet_name} - {col}",
                            'description': f"Average engagement level is {metrics['mean']:.2f}"
                        })
                
                elif category == 'learning_performance':
                    if 'mean' in metrics and 'max' in metrics:
                        insights.append({
                            'type': 'kpi',
                            'category': category,
                            'source': f"{sheet_name} - {col}",
                            'description': f"Average performance score is {metrics['mean']:.2f} out of {metrics['max']:.2f}"
                        })
                
                elif category == 'operational_efficiency':
                    if 'mean' in metrics:
                        insights.append({
                            'type': 'kpi',
                            'category': category,
                            'source': f"{sheet_name} - {col}",
                            'description': f"Average operational efficiency is {metrics['mean']:.2f}"
                        })
                
                elif category == 'training_cost':
                    if 'mean' in metrics:
                        insights.append({
                            'type': 'kpi',
                            'category': category,
                            'source': f"{sheet_name} - {col}",
                            'description': f"Average training cost is {metrics['mean']:.2f}"
                        })
        
        # Generate insights from correlations
        if correlations:
            strong_correlations = []
            
            for col1, corr_dict in correlations.items():
                for col2, corr_value in corr_dict.items():
                    # Check for strong correlations (positive or negative)
                    if abs(corr_value) >= 0.7:
                        strong_correlations.append({
                            'col1': col1,
                            'col2': col2,
                            'corr': corr_value
                        })
            
            # Sort by correlation strength (absolute value)
            strong_correlations.sort(key=lambda x: abs(x['corr']), reverse=True)
            
            # Generate insights for the top 3 strong correlations
            for i, corr in enumerate(strong_correlations[:3]):
                col1 = corr['col1']
                col2 = corr['col2']
                corr_value = corr['corr']
                
                if corr_value > 0:
                    relationship = "positive correlation"
                    description = f"As {col1} increases, {col2} tends to increase as well"
                else:
                    relationship = "negative correlation"
                    description = f"As {col1} increases, {col2} tends to decrease"
                
                insights.append({
                    'type': 'correlation',
                    'source': f"{sheet_name} - {col1} vs {col2}",
                    'description': f"Strong {relationship} ({corr_value:.2f}) between {col1} and {col2}. {description}."
                })
        
        # Generate insights from trends
        if trends:
            for trend_key, trend_data in trends.items():
                date_col = trend_data['date_column']
                metric_col = trend_data['metric_column']
                trend = trend_data['trend']
                percent_change = trend_data['percent_change']
                
                if trend == 'increasing':
                    insights.append({
                        'type': 'trend',
                        'source': f"{sheet_name} - {metric_col} over {date_col}",
                        'description': f"{metric_col} is showing an increasing trend over time ({percent_change:.2f}% change)"
                    })
                elif trend == 'decreasing':
                    insights.append({
                        'type': 'trend',
                        'source': f"{sheet_name} - {metric_col} over {date_col}",
                        'description': f"{metric_col} is showing a decreasing trend over time ({percent_change:.2f}% change)"
                    })
        
        return insights


def process_report_file(file_path, file_type, event_type):
    """
    Process a report file by extracting and analyzing data.
    
    Args:
        file_path: Path to the report file
        file_type: Type of report file ('excel', 'csv', 'pdf')
        event_type: Type of event ('created', 'modified', 'moved', 'existing')
    """
    logger.info(f"Processing {file_type} report: {file_path} (Event: {event_type})")
    
    # Create data extractor and analyzer
    extractor = DataExtractor()
    analyzer = DataAnalyzer()
    
    # Extract data from the report file
    extracted_data = extractor.extract_data(file_path, file_type)
    
    if extracted_data:
        # Analyze the extracted data
        analysis_results = analyzer.analyze_data(extracted_data)
        
        if analysis_results:
            # Save the analysis results
            results_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "analysis_results")
            os.makedirs(results_dir, exist_ok=True)
            
            # Create a filename for the analysis results
            file_name = os.path.basename(file_path)
            file_name_without_ext = os.path.splitext(file_name)[0]
            results_file = os.path.join(results_dir, f"{file_name_without_ext}_analysis.json")
            
            # Save the analysis results as JSON
            import json
            with open(results_file, 'w') as f:
                json.dump(analysis_results, f, indent=2)
            
            logger.info(f"Analysis results saved to: {results_file}")
            
            return analysis_results
    
    logger.error(f"Failed to process report file: {file_path}")
    return None


if __name__ == "__main__":
    # Example usage
    import sys
    
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        
        # Determine file type
        ext = os.path.splitext(file_path)[1].lower()
        if ext in ['.xlsx', '.xls']:
            file_type = 'excel'
        elif ext == '.csv':
            file_type = 'csv'
        elif ext == '.pdf':
            file_type = 'pdf'
        else:
            print(f"Unsupported file type: {ext}")
            sys.exit(1)
        
        # Process the file
        process_report_file(file_path, file_type, 'manual')
