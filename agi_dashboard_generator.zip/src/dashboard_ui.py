#!/usr/bin/env python3
"""
AGI Dashboard Generator - User Interface

This module provides a modern, professional user interface for the AGI Dashboard Generator,
allowing users to select folders, configure options, and view generated dashboards.
"""

import os
import sys
import json
import time
import threading
import webbrowser
from pathlib import Path
import logging
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from PIL import Image, ImageTk
import base64
from io import BytesIO

# Add parent directory to path to import other modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.file_monitor import FolderMonitor
from src.data_analyzer import DataExtractor, DataAnalyzer, process_report_file
from src.visualization_generator import VisualizationGenerator
from src.openai_analyzer import OpenAIAnalyzer, enhance_analysis_with_openai

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('AGI-Dashboard-Generator')

# Define color scheme for professional UI
UI_COLORS = {
    'primary': '#0072B2',      # Blue - primary color
    'secondary': '#D55E00',    # Orange - secondary color
    'accent': '#009E73',       # Green - accent color
    'background': '#F8F9FA',   # Light gray - background
    'text': '#212529',         # Dark gray - text
    'light_text': '#6C757D',   # Medium gray - secondary text
    'border': '#DEE2E6',       # Light gray - borders
    'hover': '#E9ECEF',        # Slightly darker gray - hover states
    'success': '#28A745',      # Green - success messages
    'warning': '#FFC107',      # Yellow - warning messages
    'error': '#DC3545'         # Red - error messages
}

class DashboardApp(tk.Tk):
    """
    Main application window for the AGI Dashboard Generator.
    """
    
    def __init__(self):
        """Initialize the application."""
        super().__init__()
        
        # Set window properties
        self.title("AGI Dashboard Generator")
        self.geometry("1200x800")
        self.minsize(1000, 700)
        self.configure(bg=UI_COLORS['background'])
        
        # Set application icon
        # self.iconbitmap('path/to/icon.ico')  # Uncomment and set path to icon if available
        
        # Initialize variables
        self.folder_path = tk.StringVar()
        self.monitor_enabled = tk.BooleanVar(value=True)
        self.excel_enabled = tk.BooleanVar(value=True)
        self.csv_enabled = tk.BooleanVar(value=True)
        self.pdf_enabled = tk.BooleanVar(value=True)
        self.analysis_depth = tk.StringVar(value="Standard")
        self.visualization_style = tk.StringVar(value="hbr")
        self.status_text = tk.StringVar(value="Ready")
        self.openai_api_key = tk.StringVar()
        self.openai_enabled = tk.BooleanVar(value=False)
        self.current_dashboard = None
        self.dashboard_list = []
        self.folder_monitor = None
        self.monitor_thread = None
        
        # Create UI elements
        self._create_menu()
        self._create_main_frame()
        
        # Initialize folder monitor
        self._initialize_folder_monitor()
        
        # Set up protocol for window close
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        
        logger.info("Dashboard application initialized")
    
    def _create_menu(self):
        """Create the application menu."""
        menubar = tk.Menu(self)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Select Folder", command=self._browse_folder)
        file_menu.add_command(label="Analyze Reports", command=self._analyze_reports)
        file_menu.add_separator()
        file_menu.add_command(label="Export Current Dashboard to CSV", command=self._export_to_csv)
        file_menu.add_command(label="Export Current Dashboard to PDF", command=self._export_to_pdf)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self._on_close)
        menubar.add_cascade(label="File", menu=file_menu)
        
        # View menu
        view_menu = tk.Menu(menubar, tearoff=0)
        view_menu.add_command(label="Refresh Dashboards", command=self._refresh_dashboards)
        view_menu.add_separator()
        
        # Visualization style submenu
        style_menu = tk.Menu(view_menu, tearoff=0)
        style_menu.add_radiobutton(label="Harvard Business Review", variable=self.visualization_style, value="hbr", command=self._change_visualization_style)
        style_menu.add_radiobutton(label="New York Times", variable=self.visualization_style, value="nyt", command=self._change_visualization_style)
        view_menu.add_cascade(label="Visualization Style", menu=style_menu)
        
        menubar.add_cascade(label="View", menu=view_menu)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="Documentation", command=self._show_documentation)
        help_menu.add_command(label="About", command=self._show_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        
        self.config(menu=menubar)
    
    def _create_main_frame(self):
        """Create the main application frame."""
        # Create main container with padding
        main_container = ttk.Frame(self, padding="10")
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Create top frame for folder selection and options
        top_frame = ttk.Frame(main_container)
        top_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Folder selection
        folder_label = ttk.Label(top_frame, text="Reports Folder:")
        folder_label.pack(side=tk.LEFT, padx=(0, 5))
        
        folder_entry = ttk.Entry(top_frame, textvariable=self.folder_path, width=50)
        folder_entry.pack(side=tk.LEFT, padx=(0, 5), fill=tk.X, expand=True)
        
        browse_button = ttk.Button(top_frame, text="Browse...", command=self._browse_folder)
        browse_button.pack(side=tk.LEFT, padx=(0, 10))
        
        analyze_button = ttk.Button(top_frame, text="Analyze Reports", command=self._analyze_reports)
        analyze_button.pack(side=tk.LEFT)
        
        # Create options frame
        options_frame = ttk.LabelFrame(main_container, text="Configuration Options")
        options_frame.pack(fill=tk.X, pady=(0, 10))
        
        # File types options
        file_types_frame = ttk.Frame(options_frame)
        file_types_frame.pack(fill=tk.X, padx=10, pady=5)
        
        file_types_label = ttk.Label(file_types_frame, text="File Types:")
        file_types_label.pack(side=tk.LEFT, padx=(0, 10))
        
        excel_check = ttk.Checkbutton(file_types_frame, text="Excel", variable=self.excel_enabled)
        excel_check.pack(side=tk.LEFT, padx=(0, 5))
        
        csv_check = ttk.Checkbutton(file_types_frame, text="CSV", variable=self.csv_enabled)
        csv_check.pack(side=tk.LEFT, padx=(0, 5))
        
        pdf_check = ttk.Checkbutton(file_types_frame, text="PDF", variable=self.pdf_enabled)
        pdf_check.pack(side=tk.LEFT, padx=(0, 5))
        
        # Analysis depth options
        analysis_frame = ttk.Frame(options_frame)
        analysis_frame.pack(fill=tk.X, padx=10, pady=5)
        
        analysis_label = ttk.Label(analysis_frame, text="Analysis Depth:")
        analysis_label.pack(side=tk.LEFT, padx=(0, 10))
        
        analysis_combo = ttk.Combobox(analysis_frame, textvariable=self.analysis_depth, 
                                      values=["Basic", "Standard", "Advanced"], state="readonly", width=15)
        analysis_combo.pack(side=tk.LEFT, padx=(0, 20))
        
        # Folder monitoring option
        monitor_check = ttk.Checkbutton(analysis_frame, text="Enable Folder Monitoring", variable=self.monitor_enabled)
        monitor_check.pack(side=tk.LEFT)
        
        # OpenAI integration options
        openai_frame = ttk.Frame(options_frame)
        openai_frame.pack(fill=tk.X, padx=10, pady=5)
        
        openai_check = ttk.Checkbutton(openai_frame, text="Enable OpenAI Analysis", variable=self.openai_enabled)
        openai_check.pack(side=tk.LEFT, padx=(0, 10))
        
        openai_label = ttk.Label(openai_frame, text="OpenAI API Key:")
        openai_label.pack(side=tk.LEFT, padx=(0, 5))
        
        openai_entry = ttk.Entry(openai_frame, textvariable=self.openai_api_key, width=40, show="*")
        openai_entry.pack(side=tk.LEFT)
        
        # Create main content frame with notebook for dashboards
        content_frame = ttk.Frame(main_container)
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create a PanedWindow to divide dashboard list and dashboard content
        paned_window = ttk.PanedWindow(content_frame, orient=tk.HORIZONTAL)
        paned_window.pack(fill=tk.BOTH, expand=True)
        
        # Left panel for dashboard list
        left_panel = ttk.Frame(paned_window, width=250)
        paned_window.add(left_panel, weight=1)
        
        # Dashboard list
        list_frame = ttk.LabelFrame(left_panel, text="Available Dashboards")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.dashboard_listbox = tk.Listbox(list_frame, selectmode=tk.SINGLE, activestyle='dotbox',
                                           bg=UI_COLORS['background'], fg=UI_COLORS['text'],
                                           selectbackground=UI_COLORS['primary'], selectforeground='white')
        self.dashboard_listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.dashboard_listbox.bind('<<ListboxSelect>>', self._on_dashboard_select)
        
        # Right panel for dashboard content
        right_panel = ttk.Frame(paned_window)
        paned_window.add(right_panel, weight=4)
        
        # Dashboard content
        dashboard_frame = ttk.LabelFrame(right_panel, text="Dashboard Viewer")
        dashboard_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create a canvas with scrollbar for dashboard content
        self.canvas_frame = ttk.Frame(dashboard_frame)
        self.canvas_frame.pack(fill=tk.BOTH, expand=True)
        
        self.canvas = tk.Canvas(self.canvas_frame, bg=UI_COLORS['background'])
        self.scrollbar = ttk.Scrollbar(self.canvas_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = ttk.Frame(self.canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        # Status bar
        status_bar = ttk.Frame(self)
        status_bar.pack(fill=tk.X, side=tk.BOTTOM)
        
        status_label = ttk.Label(status_bar, textvariable=self.status_text, anchor=tk.W)
        status_label.pack(fill=tk.X, padx=5, pady=2)
        
        # Welcome message in dashboard area
        welcome_frame = ttk.Frame(self.scrollable_frame)
        welcome_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        welcome_title = ttk.Label(welcome_frame, text="Welcome to AGI Dashboard Generator", 
                                 font=("Helvetica", 16, "bold"))
        welcome_title.pack(pady=(0, 10))
        
        welcome_text = ttk.Label(welcome_frame, text="To get started, select a folder containing your reports and click 'Analyze Reports'.",
                                wraplength=600, justify=tk.CENTER)
        welcome_text.pack(pady=(0, 20))
        
        # Instructions
        instructions_frame = ttk.LabelFrame(welcome_frame, text="Basic Workflow")
        instructions_frame.pack(fill=tk.X, padx=20, pady=10)
        
        instructions = [
            "1. Select Reports Folder: Click 'Browse...' to select a folder containing your reports",
            "2. Configure Options: Select which file types to process and choose the analysis depth",
            "3. Analyze Reports: Click 'Analyze Reports' to process the data and generate dashboards",
            "4. View Dashboards: Navigate through the generated dashboards in the dashboard viewer"
        ]
        
        for instruction in instructions:
            instr_label = ttk.Label(instructions_frame, text=instruction, wraplength=600, justify=tk.LEFT)
            instr_label.pack(anchor=tk.W, padx=10, pady=5)
    
    def _initialize_folder_monitor(self):
        """Initialize the folder monitor."""
        self.folder_monitor = FolderMonitor(callback=self._process_report_callback)
        logger.info("Folder monitor initialized")
    
    def _browse_folder(self):
        """Open a dialog to browse for a folder."""
        folder_selected = filedialog.askdirectory()
        if folder_selected:
            self.folder_path.set(folder_selected)
            self.status_text.set(f"Selected folder: {folder_selected}")
            logger.info(f"Selected folder: {folder_selected}")
            
            # Update folder monitor
            if self.folder_monitor:
                self.folder_monitor.set_folder(folder_selected)
                
                # Start monitoring if enabled
                if self.monitor_enabled.get():
                    self._start_monitoring()
    
    def _start_monitoring(self):
        """Start monitoring the selected folder."""
        if not self.folder_path.get():
            messagebox.showwarning("Warning", "Please select a folder to monitor.")
            return
        
        if self.folder_monitor and not self.folder_monitor.is_monitoring():
            # Start monitoring in a separate thread
            self.monitor_thread = threading.Thread(target=self._monitor_folder)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
            
            self.status_text.set(f"Monitoring folder: {self.folder_path.get()}")
            logger.info(f"Started monitoring folder: {self.folder_path.get()}")
    
    def _stop_monitoring(self):
        """Stop monitoring the folder."""
        if self.folder_monitor and self.folder_monitor.is_monitoring():
            self.folder_monitor.stop_monitoring()
            self.status_text.set("Folder monitoring stopped")
            logger.info("Folder monitoring stopped")
    
    def _monitor_folder(self):
        """Monitor the folder for changes."""
        if self.folder_monitor:
            self.folder_monitor.start_monitoring()
    
    def _process_report_callback(self, file_path, file_type, event_type):
        """
        Callback function for processing report files.
        
        Args:
            file_path: Path to the report file
            file_type: Type of report file ('excel', 'csv', 'pdf')
            event_type: Type of event ('created', 'modified', 'moved', 'existing')
        """
        # Check if file type is enabled
        if (file_type == 'excel' and not self.excel_enabled.get()) or \
           (file_type == 'csv' and not self.csv_enabled.get()) or \
           (file_type == 'pdf' and not self.pdf_enabled.get()):
            logger.info(f"Skipping {file_type} file: {file_path} (file type disabled)")
            return
        
        # Update status
        self.status_text.set(f"Processing {file_type} file: {os.path.basename(file_path)}")
        
        # Process the file
        try:
            # Process the report file
            analysis_results = process_report_file(file_path, file_type, event_type)
            
            if analysis_results:
                # Enhance with OpenAI if enabled
                if self.openai_enabled.get() and self.openai_api_key.get():
                    self.status_text.set(f"Enhancing analysis with OpenAI: {os.path.basename(file_path)}")
                    analysis_depth = self.analysis_depth.get().lower()
                    analysis_results = enhance_analysis_with_openai(
                        analysis_results, 
                        self.openai_api_key.get(), 
                        depth=analysis_depth
                    )
                    self.status_text.set(f"OpenAI analysis completed: {os.path.basename(file_path)}")
                
                # Generate visualizations
                self._generate_visualizations(analysis_results)
                
                # Refresh dashboard list
                self._refresh_dashboards()
                
                # Update status
                self.status_text.set(f"Processed {file_type} file: {os.path.basename(file_path)}")
                logger.info(f"Processed {file_type} file: {file_path}")
            else:
                self.status_text.set(f"Failed to process {file_type} file: {os.path.basename(file_path)}")
                logger.error(f"Failed to process {file_type} file: {file_path}")
        
        except Exception as e:
            self.status_text.set(f"Error processing file: {str(e)}")
            logger.error(f"Error processing file {file_path}: {str(e)}")
    
    def _analyze_reports(self):
        """Analyze reports in the selected folder."""
        if not self.folder_path.get():
            messagebox.showwarning("Warning", "Please select a folder containing reports.")
            return
        
        folder_path = self.folder_path.get()
        
        # Check if folder exists
        if not os.path.exists(folder_path):
            messagebox.showerror("Error", f"Folder does not exist: {folder_path}")
            return
        
        # Update status
        self.status_text.set("Analyzing reports...")
        
        # Get list of files in the folder
        files = []
        for root, _, filenames in os.walk(folder_path):
            for filename in filenames:
                file_path = os.path.join(root, filename)
                ext = os.path.splitext(filename)[1].lower()
                
                if (ext in ['.xlsx', '.xls'] and self.excel_enabled.get()) or \
                   (ext == '.csv' and self.csv_enabled.get()) or \
                   (ext == '.pdf' and self.pdf_enabled.get()):
                    files.append(file_path)
        
        if not files:
            messagebox.showinfo("Information", "No supported report files found in the selected folder.")
            self.status_text.set("No supported report files found")
            return
        
        # Process files in a separate thread
        threading.Thread(target=self._process_files, args=(files,), daemon=True).start()
    
    def _process_files(self, files):
        """
        Process a list of files.
        
        Args:
            files: List of file paths to process
        """
        total_files = len(files)
        processed_files = 0
        
        for file_path in files:
            # Update status
            processed_files += 1
            self.status_text.set(f"Processing file {processed_files}/{total_files}: {os.path.basename(file_path)}")
            
            # Determine file type
            ext = os.path.splitext(file_path)[1].lower()
            if ext in ['.xlsx', '.xls']:
                file_type = 'excel'
            elif ext == '.csv':
                file_type = 'csv'
            elif ext == '.pdf':
                file_type = 'pdf'
            else:
                continue
            
            try:
                # Process the report file
                analysis_results = process_report_file(file_path, file_type, 'manual')
                
                if analysis_results:
                    # Enhance with OpenAI if enabled
                    if self.openai_enabled.get() and self.openai_api_key.get():
                        self.status_text.set(f"Enhancing analysis with OpenAI: {os.path.basename(file_path)}")
                        analysis_depth = self.analysis_depth.get().lower()
                        analysis_results = enhance_analysis_with_openai(
                            analysis_results, 
                            self.openai_api_key.get(), 
                            depth=analysis_depth
                        )
                        self.status_text.set(f"OpenAI analysis completed: {os.path.basename(file_path)}")
                    
                    # Generate visualizations
                    self._generate_visualizations(analysis_results)
            
            except Exception as e:
                logger.error(f"Error processing file {file_path}: {str(e)}")
        
        # Refresh dashboard list
        self._refresh_dashboards()
        
        # Update status
        self.status_text.set(f"Processed {processed_files} files")
        
        # Show completion message
        messagebox.showinfo("Analysis Complete", f"Processed {processed_files} files and generated dashboards.")
    
    def _generate_visualizations(self, analysis_results):
        """
        Generate visualizations for analysis results.
        
        Args:
            analysis_results: Analysis results from DataAnalyzer
        """
        # Create visualization generator
        generator = VisualizationGenerator(style=self.visualization_style.get())
        
        # Generate visualizations
        generator.generate_visualizations(analysis_results)
    
    def _refresh_dashboards(self):
        """Refresh the list of available dashboards."""
        # Clear current list
        self.dashboard_listbox.delete(0, tk.END)
        self.dashboard_list = []
        
        # Get base directory
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        visualizations_dir = os.path.join(base_dir, "data", "visualizations")
        
        if not os.path.exists(visualizations_dir):
            return
        
        # Get list of dashboard directories
        for item in os.listdir(visualizations_dir):
            item_path = os.path.join(visualizations_dir, item)
            if os.path.isdir(item_path):
                # Check if metadata file exists
                metadata_file = os.path.join(item_path, "visualization_metadata.json")
                if os.path.exists(metadata_file):
                    try:
                        with open(metadata_file, 'r') as f:
                            metadata = json.load(f)
                        
                        # Add to dashboard list
                        self.dashboard_list.append({
                            'name': item,
                            'path': item_path,
                            'metadata': metadata
                        })
                        
                        # Add to listbox
                        self.dashboard_listbox.insert(tk.END, item)
                    
                    except Exception as e:
                        logger.error(f"Error loading dashboard metadata: {str(e)}")
        
        # Update status
        self.status_text.set(f"Found {len(self.dashboard_list)} dashboards")
    
    def _on_dashboard_select(self, event):
        """
        Handle dashboard selection event.
        
        Args:
            event: Selection event
        """
        # Get selected index
        selection = self.dashboard_listbox.curselection()
        if not selection:
            return
        
        index = selection[0]
        if index < 0 or index >= len(self.dashboard_list):
            return
        
        # Get selected dashboard
        dashboard = self.dashboard_list[index]
        self.current_dashboard = dashboard
        
        # Display dashboard
        self._display_dashboard(dashboard)
    
    def _display_dashboard(self, dashboard):
        """
        Display a dashboard.
        
        Args:
            dashboard: Dashboard data
        """
        # Clear current dashboard
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()
        
        # Create dashboard header
        header_frame = ttk.Frame(self.scrollable_frame)
        header_frame.pack(fill=tk.X, padx=20, pady=(20, 10))
        
        title = ttk.Label(header_frame, text=f"Dashboard: {dashboard['name']}", font=("Helvetica", 16, "bold"))
        title.pack(side=tk.LEFT)
        
        # Export buttons
        export_frame = ttk.Frame(header_frame)
        export_frame.pack(side=tk.RIGHT)
        
        csv_button = ttk.Button(export_frame, text="Export to CSV", command=self._export_to_csv)
        csv_button.pack(side=tk.LEFT, padx=(0, 5))
        
        pdf_button = ttk.Button(export_frame, text="Export to PDF", command=self._export_to_pdf)
        pdf_button.pack(side=tk.LEFT)
        
        # Check if we have AI insights to display
        dashboard_name = dashboard['name']
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        enhanced_analysis_file = os.path.join(base_dir, "data", "analysis_results", f"{dashboard_name}_enhanced_analysis.json")
        
        has_ai_insights = os.path.exists(enhanced_analysis_file)
        
        # Create dashboard content
        content_frame = ttk.Frame(self.scrollable_frame)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # If we have AI insights, add a tab for them
        if has_ai_insights:
            # Create a notebook for tabs
            notebook = ttk.Notebook(content_frame)
            notebook.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
            
            # Create tabs
            visualizations_tab = ttk.Frame(notebook)
            ai_insights_tab = ttk.Frame(notebook)
            
            notebook.add(visualizations_tab, text="Visualizations")
            notebook.add(ai_insights_tab, text="AI Insights")
            
            # Load AI insights
            try:
                with open(enhanced_analysis_file, 'r') as f:
                    enhanced_analysis = json.load(f)
                
                ai_insights = enhanced_analysis.get('ai_insights', {})
                
                # Create AI insights content
                ai_content_frame = ttk.Frame(ai_insights_tab)
                ai_content_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
                
                # Executive Summary
                if 'executive_summary' in ai_insights:
                    summary_frame = ttk.LabelFrame(ai_content_frame, text="Executive Summary")
                    summary_frame.pack(fill=tk.X, pady=(0, 15))
                    
                    summary_text = ai_insights['executive_summary']
                    summary_label = ttk.Label(summary_frame, text=summary_text, wraplength=800, justify=tk.LEFT)
                    summary_label.pack(padx=10, pady=10)
                
                # Tabular Analysis
                if 'tabular_analysis' in ai_insights:
                    tabular_frame = ttk.LabelFrame(ai_content_frame, text="Data Analysis")
                    tabular_frame.pack(fill=tk.X, pady=(0, 15))
                    
                    tabular_analysis = ai_insights['tabular_analysis']
                    
                    # Key Findings
                    if 'key_findings' in tabular_analysis:
                        findings_frame = ttk.Frame(tabular_frame)
                        findings_frame.pack(fill=tk.X, padx=10, pady=10)
                        
                        findings_label = ttk.Label(findings_frame, text="Key Findings:", font=("Helvetica", 10, "bold"))
                        findings_label.pack(anchor=tk.W)
                        
                        for i, finding in enumerate(tabular_analysis['key_findings']):
                            finding_label = ttk.Label(findings_frame, text=f"{i+1}. {finding}", wraplength=780, justify=tk.LEFT)
                            finding_label.pack(anchor=tk.W, pady=(5, 0))
                    
                    # Business Implications
                    if 'business_implications' in tabular_analysis:
                        implications_frame = ttk.Frame(tabular_frame)
                        implications_frame.pack(fill=tk.X, padx=10, pady=10)
                        
                        implications_label = ttk.Label(implications_frame, text="Business Implications:", font=("Helvetica", 10, "bold"))
                        implications_label.pack(anchor=tk.W)
                        
                        for i, implication in enumerate(tabular_analysis['business_implications']):
                            implication_label = ttk.Label(implications_frame, text=f"{i+1}. {implication}", wraplength=780, justify=tk.LEFT)
                            implication_label.pack(anchor=tk.W, pady=(5, 0))
                
                # Recommendations
                if 'recommendations' in ai_insights:
                    recommendations_frame = ttk.LabelFrame(ai_content_frame, text="Strategic Recommendations")
                    recommendations_frame.pack(fill=tk.X, pady=(0, 15))
                    
                    recommendations = ai_insights['recommendations']
                    
                    for i, recommendation in enumerate(recommendations):
                        recommendation_label = ttk.Label(recommendations_frame, text=f"{i+1}. {recommendation}", 
                                                      wraplength=780, justify=tk.LEFT)
                        recommendation_label.pack(anchor=tk.W, padx=10, pady=5)
                
                # Set visualizations_tab as the content frame for charts
                content_frame = visualizations_tab
            
            except Exception as e:
                logger.error(f"Error loading AI insights: {str(e)}")
                error_label = ttk.Label(ai_insights_tab, text=f"Error loading AI insights: {str(e)}", 
                                      wraplength=800, foreground="red")
                error_label.pack(padx=20, pady=20)
        
        # Get charts from metadata
        charts = dashboard['metadata'].get('charts', [])
        
        if not charts:
            no_charts_label = ttk.Label(content_frame, text="No charts available for this dashboard.",
                                      font=("Helvetica", 12))
            no_charts_label.pack(pady=20)
            return
        
        # Group charts by category
        charts_by_category = {}
        for chart in charts:
            category = chart.get('category', 'other')
            if category not in charts_by_category:
                charts_by_category[category] = []
            
            charts_by_category[category].append(chart)
        
        # Display charts by category
        for category, category_charts in charts_by_category.items():
            # Create category frame
            category_frame = ttk.LabelFrame(content_frame, text=category.replace('_', ' ').title())
            category_frame.pack(fill=tk.X, pady=(0, 15))
            
            # Create grid for charts
            grid_frame = ttk.Frame(category_frame)
            grid_frame.pack(fill=tk.X, padx=10, pady=10)
            
            # Add charts to grid
            for i, chart in enumerate(category_charts):
                chart_type = chart.get('type', '')
                chart_title = chart.get('title', '')
                chart_file = chart.get('file', '')
                chart_path = chart.get('path', '')
                
                # Skip if chart file doesn't exist
                if not os.path.exists(chart_path):
                    continue
                
                # Create chart frame
                chart_frame = ttk.Frame(grid_frame)
                chart_frame.grid(row=i//2, column=i%2, padx=10, pady=10, sticky=tk.NW)
                
                # Add chart title
                title_label = ttk.Label(chart_frame, text=chart_title, font=("Helvetica", 10, "bold"))
                title_label.pack(pady=(0, 5))
                
                # Display chart based on type
                if chart_type in ['bar', 'line', 'radar', 'heatmap']:
                    # Display static image
                    try:
                        img = Image.open(chart_path)
                        img = img.resize((400, 300), Image.LANCZOS)
                        photo = ImageTk.PhotoImage(img)
                        
                        img_label = ttk.Label(chart_frame, image=photo)
                        img_label.image = photo  # Keep a reference to prevent garbage collection
                        img_label.pack()
                        
                        # Add view button for interactive version if available
                        interactive_file = chart_file.replace('.png', '_interactive.html')
                        interactive_path = os.path.join(os.path.dirname(chart_path), interactive_file)
                        
                        if os.path.exists(interactive_path):
                            view_button = ttk.Button(chart_frame, text="View Interactive",
                                                  command=lambda p=interactive_path: self._open_interactive_chart(p))
                            view_button.pack(pady=(5, 0))
                    
                    except Exception as e:
                        error_label = ttk.Label(chart_frame, text=f"Error loading chart: {str(e)}")
                        error_label.pack()
                
                elif chart_type in ['interactive_bar', 'interactive_line', 'interactive_heatmap']:
                    # Display button to open interactive chart
                    view_button = ttk.Button(chart_frame, text="Open Interactive Chart",
                                          command=lambda p=chart_path: self._open_interactive_chart(p))
                    view_button.pack(pady=10)
                    
                    # Add preview text
                    preview_label = ttk.Label(chart_frame, text="Interactive visualization available.\nClick the button above to open it in your browser.")
                    preview_label.pack()
    
    def _open_interactive_chart(self, chart_path):
        """
        Open an interactive chart in the default web browser.
        
        Args:
            chart_path: Path to the interactive chart HTML file
        """
        if os.path.exists(chart_path):
            webbrowser.open(f"file://{chart_path}")
            self.status_text.set(f"Opened interactive chart: {os.path.basename(chart_path)}")
        else:
            messagebox.showerror("Error", f"Chart file not found: {chart_path}")
    
    def _export_to_csv(self):
        """Export the current dashboard data to CSV."""
        if not self.current_dashboard:
            messagebox.showwarning("Warning", "No dashboard selected.")
            return
        
        # Get file path
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile=f"{self.current_dashboard['name']}_export.csv"
        )
        
        if not file_path:
            return
        
        try:
            # Get analysis results
            dashboard_name = self.current_dashboard['name']
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            analysis_file = os.path.join(base_dir, "data", "analysis_results", f"{dashboard_name}_analysis.json")
            
            if not os.path.exists(analysis_file):
                messagebox.showerror("Error", f"Analysis results not found for dashboard: {dashboard_name}")
                return
            
            # Load analysis results
            with open(analysis_file, 'r') as f:
                analysis_results = json.load(f)
            
            # Extract data for CSV export
            if analysis_results['file_type'] in ['excel', 'csv']:
                # Get the first sheet data
                sheet_name = list(analysis_results['summary'].keys())[0]
                
                # Create a DataFrame with insights
                insights_df = pd.DataFrame(analysis_results.get('insights', []))
                
                # Save to CSV
                insights_df.to_csv(file_path, index=False)
                
                self.status_text.set(f"Exported dashboard to CSV: {file_path}")
                messagebox.showinfo("Export Complete", f"Dashboard exported to CSV: {file_path}")
            
            else:
                messagebox.showerror("Error", f"CSV export not supported for file type: {analysis_results['file_type']}")
        
        except Exception as e:
            messagebox.showerror("Export Error", f"Error exporting to CSV: {str(e)}")
            logger.error(f"Error exporting to CSV: {str(e)}")
    
    def _export_to_pdf(self):
        """Export the current dashboard to PDF."""
        if not self.current_dashboard:
            messagebox.showwarning("Warning", "No dashboard selected.")
            return
        
        # Get file path
        file_path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")],
            initialfile=f"{self.current_dashboard['name']}_dashboard.pdf"
        )
        
        if not file_path:
            return
        
        try:
            # Import reportlab for PDF generation
            from reportlab.lib.pagesizes import letter, landscape
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as RLImage, Table, TableStyle
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import inch
            
            # Create PDF document
            doc = SimpleDocTemplate(file_path, pagesize=landscape(letter))
            
            # Get styles
            styles = getSampleStyleSheet()
            title_style = styles['Title']
            heading_style = styles['Heading2']
            normal_style = styles['Normal']
            
            # Create content elements
            elements = []
            
            # Add title
            elements.append(Paragraph(f"Dashboard: {self.current_dashboard['name']}", title_style))
            elements.append(Spacer(1, 0.25*inch))
            
            # Get charts from metadata
            charts = self.current_dashboard['metadata'].get('charts', [])
            
            if not charts:
                elements.append(Paragraph("No charts available for this dashboard.", normal_style))
            else:
                # Group charts by category
                charts_by_category = {}
                for chart in charts:
                    category = chart.get('category', 'other')
                    if category not in charts_by_category:
                        charts_by_category[category] = []
                    
                    charts_by_category[category].append(chart)
                
                # Add charts by category
                for category, category_charts in charts_by_category.items():
                    # Add category heading
                    elements.append(Paragraph(category.replace('_', ' ').title(), heading_style))
                    elements.append(Spacer(1, 0.1*inch))
                    
                    # Add charts
                    for chart in category_charts:
                        chart_title = chart.get('title', '')
                        chart_path = chart.get('path', '')
                        
                        # Skip interactive charts and non-existent files
                        if not os.path.exists(chart_path) or not chart_path.endswith('.png'):
                            continue
                        
                        # Add chart title
                        elements.append(Paragraph(chart_title, normal_style))
                        
                        # Add chart image
                        img = RLImage(chart_path, width=6*inch, height=4*inch)
                        elements.append(img)
                        elements.append(Spacer(1, 0.2*inch))
            
            # Build PDF
            doc.build(elements)
            
            self.status_text.set(f"Exported dashboard to PDF: {file_path}")
            messagebox.showinfo("Export Complete", f"Dashboard exported to PDF: {file_path}")
        
        except Exception as e:
            messagebox.showerror("Export Error", f"Error exporting to PDF: {str(e)}")
            logger.error(f"Error exporting to PDF: {str(e)}")
    
    def _change_visualization_style(self):
        """Change the visualization style."""
        style = self.visualization_style.get()
        logger.info(f"Changed visualization style to: {style}")
        
        # Update status
        self.status_text.set(f"Visualization style changed to: {style}")
        
        # Regenerate visualizations if needed
        if messagebox.askyesno("Regenerate Visualizations", 
                              "Do you want to regenerate all visualizations with the new style?"):
            self._regenerate_visualizations()
    
    def _regenerate_visualizations(self):
        """Regenerate all visualizations with the current style."""
        # Get base directory
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        analysis_dir = os.path.join(base_dir, "data", "analysis_results")
        
        if not os.path.exists(analysis_dir):
            messagebox.showinfo("Information", "No analysis results found to regenerate visualizations.")
            return
        
        # Get list of analysis files
        analysis_files = []
        for filename in os.listdir(analysis_dir):
            if filename.endswith('_analysis.json'):
                analysis_files.append(os.path.join(analysis_dir, filename))
        
        if not analysis_files:
            messagebox.showinfo("Information", "No analysis results found to regenerate visualizations.")
            return
        
        # Update status
        self.status_text.set("Regenerating visualizations...")
        
        # Process files in a separate thread
        threading.Thread(target=self._regenerate_visualizations_thread, 
                        args=(analysis_files,), daemon=True).start()
    
    def _regenerate_visualizations_thread(self, analysis_files):
        """
        Regenerate visualizations in a separate thread.
        
        Args:
            analysis_files: List of analysis result files
        """
        total_files = len(analysis_files)
        processed_files = 0
        
        for file_path in analysis_files:
            # Update status
            processed_files += 1
            self.status_text.set(f"Regenerating visualizations {processed_files}/{total_files}: {os.path.basename(file_path)}")
            
            try:
                # Load analysis results
                with open(file_path, 'r') as f:
                    analysis_results = json.load(f)
                
                # Generate visualizations
                self._generate_visualizations(analysis_results)
            
            except Exception as e:
                logger.error(f"Error regenerating visualizations for {file_path}: {str(e)}")
        
        # Refresh dashboard list
        self._refresh_dashboards()
        
        # Update status
        self.status_text.set(f"Regenerated visualizations for {processed_files} files")
        
        # Show completion message
        messagebox.showinfo("Regeneration Complete", f"Regenerated visualizations for {processed_files} files.")
    
    def _show_documentation(self):
        """Show documentation."""
        doc_text = """
        # AGI Dashboard Generator Documentation
        
        ## Basic Workflow
        
        1. **Select Reports Folder**: Click "Browse..." to select a folder containing your reports
        2. **Configure Options**: 
           - Select which file types to process
           - Choose the analysis depth
           - Enable/disable folder monitoring
        3. **Analyze Reports**: Click "Analyze Reports" to process the data and generate dashboards
        4. **View Dashboards**: Navigate through the generated dashboards in the dashboard viewer
        
        ## Analysis Depth Options
        
        - **Basic**: Quick analysis with fundamental statistics and simple visualizations
        - **Standard**: Comprehensive analysis with correlations and more detailed visualizations
        - **Advanced**: In-depth analysis with advanced statistical methods and detailed insights
        
        ## Dashboard Types
        
        The application generates several types of visualizations based on the data:
        
        - **Data Overview**: Summary of the dataset structure and characteristics
        - **Missing Values**: Analysis of missing data points
        - **Numeric Distribution**: Distribution and statistics for numeric columns
        - **Categorical Distribution**: Distribution of categorical values
        - **Correlations**: Heatmap showing relationships between numeric columns
        - **Time Series**: Trends over time for date-based data
        
        ## Export Options
        
        - **CSV Export**: Export dashboard data to CSV format
        - **PDF Export**: Export dashboard visualizations to PDF format
        """
        
        # Create documentation window
        doc_window = tk.Toplevel(self)
        doc_window.title("AGI Dashboard Generator Documentation")
        doc_window.geometry("800x600")
        doc_window.minsize(600, 400)
        
        # Create text widget
        text_frame = ttk.Frame(doc_window, padding="10")
        text_frame.pack(fill=tk.BOTH, expand=True)
        
        text_widget = tk.Text(text_frame, wrap=tk.WORD, padx=10, pady=10)
        text_widget.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        scrollbar = ttk.Scrollbar(text_frame, command=text_widget.yview)
        scrollbar.pack(fill=tk.Y, side=tk.RIGHT)
        
        text_widget.config(yscrollcommand=scrollbar.set)
        
        # Insert documentation text
        text_widget.insert(tk.END, doc_text)
        text_widget.config(state=tk.DISABLED)
    
    def _show_about(self):
        """Show about dialog."""
        about_text = """
        AGI Dashboard Generator
        
        A desktop application that can:
        
        1. Monitor a folder for reports in various formats (Excel, CSV, PDF)
        2. Analyze the data in these reports to extract meaningful insights
        3. Automatically generate interactive dashboards with visualizations
        4. Present these dashboards in an easy-to-use interface
        
        This eliminates the need to manually build custom dashboards for your data,
        saving time and providing immediate insights.
        """
        
        messagebox.showinfo("About AGI Dashboard Generator", about_text)
    
    def _on_close(self):
        """Handle window close event."""
        # Stop monitoring
        self._stop_monitoring()
        
        # Destroy window
        self.destroy()


if __name__ == "__main__":
    # Create and run the application
    app = DashboardApp()
    app.mainloop()
