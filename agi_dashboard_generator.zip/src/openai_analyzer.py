#!/usr/bin/env python3
"""
AGI Dashboard Generator - OpenAI Integration

This module provides functionality to leverage OpenAI's API for deeper data analysis
of reports and generation of insights.
"""

import os
import json
import logging
import pandas as pd
import numpy as np
import requests
from typing import Dict, List, Any, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('AGI-Dashboard-Generator')

class OpenAIAnalyzer:
    """
    Leverage OpenAI's API for deeper data analysis and insights generation.
    """
    
    def __init__(self, api_key=None):
        """
        Initialize the OpenAI analyzer.
        
        Args:
            api_key: OpenAI API key (optional, can be set later)
        """
        self.api_key = api_key
        self.api_url = "https://api.openai.com/v1/chat/completions"
        self.model = "gpt-4"  # Default to GPT-4 for best analysis
        logger.info("OpenAI analyzer initialized")
    
    def set_api_key(self, api_key):
        """
        Set the OpenAI API key.
        
        Args:
            api_key: OpenAI API key
        """
        self.api_key = api_key
        logger.info("OpenAI API key set")
    
    def set_model(self, model):
        """
        Set the OpenAI model to use.
        
        Args:
            model: OpenAI model name (e.g., "gpt-4", "gpt-3.5-turbo")
        """
        self.model = model
        logger.info(f"OpenAI model set to {model}")
    
    def analyze_data(self, analysis_results, depth="standard"):
        """
        Analyze data using OpenAI API to generate deeper insights.
        
        Args:
            analysis_results: Analysis results from DataAnalyzer
            depth: Analysis depth ("basic", "standard", "advanced")
            
        Returns:
            dict: Enhanced analysis results with AI-generated insights
        """
        if not self.api_key:
            logger.error("OpenAI API key not set")
            return analysis_results
        
        logger.info(f"Performing {depth} OpenAI analysis on {analysis_results['file_name']}")
        
        # Create a copy of the analysis results
        enhanced_results = analysis_results.copy()
        
        # Add AI insights section if it doesn't exist
        if 'ai_insights' not in enhanced_results:
            enhanced_results['ai_insights'] = {}
        
        # Process based on file type
        file_type = analysis_results['file_type']
        
        if file_type in ['excel', 'csv']:
            # Analyze tabular data
            ai_insights = self._analyze_tabular_data(analysis_results, depth)
            if ai_insights:
                enhanced_results['ai_insights']['tabular_analysis'] = ai_insights
        
        elif file_type == 'pdf':
            # Analyze PDF data
            ai_insights = self._analyze_pdf_data(analysis_results, depth)
            if ai_insights:
                enhanced_results['ai_insights']['pdf_analysis'] = ai_insights
        
        # Generate executive summary
        summary = self._generate_executive_summary(enhanced_results, depth)
        if summary:
            enhanced_results['ai_insights']['executive_summary'] = summary
        
        # Generate recommendations
        recommendations = self._generate_recommendations(enhanced_results, depth)
        if recommendations:
            enhanced_results['ai_insights']['recommendations'] = recommendations
        
        logger.info(f"OpenAI analysis completed for {analysis_results['file_name']}")
        return enhanced_results
    
    def _analyze_tabular_data(self, analysis_results, depth):
        """
        Analyze tabular data (Excel, CSV) using OpenAI API.
        
        Args:
            analysis_results: Analysis results from DataAnalyzer
            depth: Analysis depth
            
        Returns:
            dict: AI-generated insights for tabular data
        """
        # Extract relevant information for analysis
        summary = analysis_results.get('summary', {})
        kpi_metrics = analysis_results.get('kpi_metrics', {})
        correlations = analysis_results.get('correlations', {})
        trends = analysis_results.get('trends', {})
        insights = analysis_results.get('insights', [])
        
        # Prepare data for OpenAI
        data_description = self._prepare_data_description(summary, kpi_metrics, correlations, trends, insights)
        
        # Define prompt based on analysis depth
        if depth == "basic":
            prompt = f"""
            Analyze the following data summary and provide basic insights:
            
            {data_description}
            
            Focus on:
            1. Key patterns in the data
            2. Basic interpretation of the metrics
            3. Simple recommendations
            
            Format your response as JSON with the following structure:
            {{
                "key_findings": [list of 3-5 key findings],
                "patterns": [list of identified patterns],
                "interpretation": [interpretation of key metrics],
                "business_implications": [list of business implications]
            }}
            """
        
        elif depth == "advanced":
            prompt = f"""
            Perform an advanced analysis of the following data and provide detailed insights:
            
            {data_description}
            
            Focus on:
            1. Complex patterns and relationships in the data
            2. Detailed interpretation of all metrics and correlations
            3. Advanced statistical insights
            4. Comprehensive business implications
            5. Detailed strategic recommendations
            6. Potential future trends based on the data
            
            Format your response as JSON with the following structure:
            {{
                "key_findings": [list of 5-8 detailed key findings],
                "patterns": [list of complex patterns identified],
                "correlations_analysis": [detailed analysis of correlations],
                "statistical_insights": [advanced statistical observations],
                "business_implications": [comprehensive business implications],
                "strategic_recommendations": [detailed strategic recommendations],
                "future_trends": [predicted future trends based on data]
            }}
            """
        
        else:  # standard
            prompt = f"""
            Analyze the following data and provide comprehensive insights:
            
            {data_description}
            
            Focus on:
            1. Key patterns and trends in the data
            2. Interpretation of metrics and correlations
            3. Business implications
            4. Strategic recommendations
            
            Format your response as JSON with the following structure:
            {{
                "key_findings": [list of 4-6 key findings],
                "patterns": [list of patterns identified],
                "correlations_analysis": [analysis of important correlations],
                "business_implications": [list of business implications],
                "strategic_recommendations": [list of strategic recommendations]
            }}
            """
        
        # Call OpenAI API
        response = self._call_openai_api(prompt)
        
        if response:
            try:
                # Extract JSON from response
                json_str = response.strip()
                if json_str.startswith("```json"):
                    json_str = json_str.split("```json")[1]
                if json_str.endswith("```"):
                    json_str = json_str.split("```")[0]
                
                # Parse JSON
                ai_insights = json.loads(json_str)
                return ai_insights
            
            except Exception as e:
                logger.error(f"Error parsing OpenAI response: {str(e)}")
                return {"error": "Failed to parse OpenAI response", "raw_response": response}
        
        return None
    
    def _analyze_pdf_data(self, analysis_results, depth):
        """
        Analyze PDF data using OpenAI API.
        
        Args:
            analysis_results: Analysis results from DataAnalyzer
            depth: Analysis depth
            
        Returns:
            dict: AI-generated insights for PDF data
        """
        # Extract text content and key terms
        text = analysis_results.get('data', {}).get('text', '')
        key_terms = analysis_results.get('key_terms', {})
        
        # Truncate text if too long (OpenAI has token limits)
        if len(text) > 10000:
            text = text[:10000] + "... [text truncated]"
        
        # Prepare key terms description
        key_terms_description = ""
        for category, terms in key_terms.items():
            key_terms_description += f"\nCategory: {category}\nTerms: {', '.join(terms)}\n"
        
        # Define prompt based on analysis depth
        if depth == "basic":
            prompt = f"""
            Analyze the following document text and key terms and provide basic insights:
            
            TEXT EXCERPT:
            {text}
            
            KEY TERMS:
            {key_terms_description}
            
            Focus on:
            1. Main topics and themes
            2. Basic summary of content
            3. Simple implications
            
            Format your response as JSON with the following structure:
            {{
                "main_topics": [list of main topics],
                "summary": "brief summary of the document",
                "key_points": [list of key points],
                "basic_implications": [list of basic implications]
            }}
            """
        
        elif depth == "advanced":
            prompt = f"""
            Perform an advanced analysis of the following document text and key terms:
            
            TEXT EXCERPT:
            {text}
            
            KEY TERMS:
            {key_terms_description}
            
            Focus on:
            1. Detailed analysis of main topics and themes
            2. Comprehensive content analysis
            3. Identification of subtle patterns and implications
            4. Critical evaluation of the document
            5. Detailed recommendations based on the content
            
            Format your response as JSON with the following structure:
            {{
                "main_topics": [list of main topics with detailed descriptions],
                "content_analysis": "comprehensive analysis of the document content",
                "patterns": [list of identified patterns and relationships],
                "critical_evaluation": "critical evaluation of the document",
                "detailed_implications": [list of detailed implications],
                "recommendations": [list of specific recommendations]
            }}
            """
        
        else:  # standard
            prompt = f"""
            Analyze the following document text and key terms and provide comprehensive insights:
            
            TEXT EXCERPT:
            {text}
            
            KEY TERMS:
            {key_terms_description}
            
            Focus on:
            1. Main topics and themes
            2. Content summary and analysis
            3. Key implications
            4. Recommendations based on the content
            
            Format your response as JSON with the following structure:
            {{
                "main_topics": [list of main topics],
                "content_analysis": "analysis of the document content",
                "key_points": [list of key points],
                "implications": [list of implications],
                "recommendations": [list of recommendations]
            }}
            """
        
        # Call OpenAI API
        response = self._call_openai_api(prompt)
        
        if response:
            try:
                # Extract JSON from response
                json_str = response.strip()
                if json_str.startswith("```json"):
                    json_str = json_str.split("```json")[1]
                if json_str.endswith("```"):
                    json_str = json_str.split("```")[0]
                
                # Parse JSON
                ai_insights = json.loads(json_str)
                return ai_insights
            
            except Exception as e:
                logger.error(f"Error parsing OpenAI response: {str(e)}")
                return {"error": "Failed to parse OpenAI response", "raw_response": response}
        
        return None
    
    def _generate_executive_summary(self, analysis_results, depth):
        """
        Generate an executive summary using OpenAI API.
        
        Args:
            analysis_results: Enhanced analysis results
            depth: Analysis depth
            
        Returns:
            str: Executive summary
        """
        # Extract AI insights
        ai_insights = analysis_results.get('ai_insights', {})
        
        # Extract original insights
        insights = analysis_results.get('insights', [])
        
        # Prepare insights description
        insights_description = ""
        for insight in insights:
            insights_description += f"\n- {insight.get('description', '')}"
        
        # Define prompt based on analysis depth
        if depth == "basic":
            prompt = f"""
            Generate a brief executive summary based on the following insights:
            
            ORIGINAL INSIGHTS:
            {insights_description}
            
            AI INSIGHTS:
            {json.dumps(ai_insights, indent=2)}
            
            Create a concise executive summary (3-4 sentences) that highlights the most important findings.
            """
        
        elif depth == "advanced":
            prompt = f"""
            Generate a comprehensive executive summary based on the following insights:
            
            ORIGINAL INSIGHTS:
            {insights_description}
            
            AI INSIGHTS:
            {json.dumps(ai_insights, indent=2)}
            
            Create a detailed executive summary (1-2 paragraphs) that:
            1. Highlights the most important findings
            2. Explains the business implications
            3. Provides strategic context
            4. Suggests high-level next steps
            
            The summary should be suitable for C-level executives and provide actionable intelligence.
            """
        
        else:  # standard
            prompt = f"""
            Generate an executive summary based on the following insights:
            
            ORIGINAL INSIGHTS:
            {insights_description}
            
            AI INSIGHTS:
            {json.dumps(ai_insights, indent=2)}
            
            Create a clear executive summary (5-7 sentences) that highlights the key findings and their implications.
            """
        
        # Call OpenAI API
        response = self._call_openai_api(prompt)
        
        return response.strip() if response else None
    
    def _generate_recommendations(self, analysis_results, depth):
        """
        Generate recommendations using OpenAI API.
        
        Args:
            analysis_results: Enhanced analysis results
            depth: Analysis depth
            
        Returns:
            list: Recommendations
        """
        # Extract AI insights
        ai_insights = analysis_results.get('ai_insights', {})
        
        # Extract original insights
        insights = analysis_results.get('insights', [])
        
        # Prepare insights description
        insights_description = ""
        for insight in insights:
            insights_description += f"\n- {insight.get('description', '')}"
        
        # Define prompt based on analysis depth
        if depth == "basic":
            prompt = f"""
            Generate basic recommendations based on the following insights:
            
            ORIGINAL INSIGHTS:
            {insights_description}
            
            AI INSIGHTS:
            {json.dumps(ai_insights, indent=2)}
            
            Provide 3-4 basic recommendations in JSON format:
            [
                "First recommendation",
                "Second recommendation",
                ...
            ]
            """
        
        elif depth == "advanced":
            prompt = f"""
            Generate detailed strategic recommendations based on the following insights:
            
            ORIGINAL INSIGHTS:
            {insights_description}
            
            AI INSIGHTS:
            {json.dumps(ai_insights, indent=2)}
            
            Provide 6-8 detailed strategic recommendations in JSON format:
            [
                "First detailed recommendation with strategic context",
                "Second detailed recommendation with strategic context",
                ...
            ]
            
            Each recommendation should be specific, actionable, and include strategic context.
            """
        
        else:  # standard
            prompt = f"""
            Generate strategic recommendations based on the following insights:
            
            ORIGINAL INSIGHTS:
            {insights_description}
            
            AI INSIGHTS:
            {json.dumps(ai_insights, indent=2)}
            
            Provide 4-6 strategic recommendations in JSON format:
            [
                "First strategic recommendation",
                "Second strategic recommendation",
                ...
            ]
            """
        
        # Call OpenAI API
        response = self._call_openai_api(prompt)
        
        if response:
            try:
                # Extract JSON from response
                json_str = response.strip()
                if json_str.startswith("```json"):
                    json_str = json_str.split("```json")[1]
                if json_str.endswith("```"):
                    json_str = json_str.split("```")[0]
                
                # Parse JSON
                recommendations = json.loads(json_str)
                return recommendations
            
            except Exception as e:
                logger.error(f"Error parsing OpenAI recommendations: {str(e)}")
                return [f"Error generating recommendations: {str(e)}"]
        
        return None
    
    def _prepare_data_description(self, summary, kpi_metrics, correlations, trends, insights):
        """
        Prepare a description of the data for OpenAI analysis.
        
        Args:
            summary: Data summary
            kpi_metrics: KPI metrics
            correlations: Correlations
            trends: Trends
            insights: Insights
            
        Returns:
            str: Data description
        """
        description = "DATA SUMMARY:\n"
        
        # Add summary information
        for sheet_name, sheet_summary in summary.items():
            description += f"\nSheet/Table: {sheet_name}\n"
            description += f"Rows: {sheet_summary.get('row_count', 'N/A')}, Columns: {sheet_summary.get('column_count', 'N/A')}\n"
            
            # Add column information
            description += "Columns: " + ", ".join(sheet_summary.get('column_names', [])) + "\n"
            
            # Add numeric statistics
            if 'numeric_stats' in sheet_summary:
                description += "\nNumeric Statistics:\n"
                for col, stats in sheet_summary['numeric_stats'].items():
                    description += f"- {col}: Min={stats.get('min', 'N/A')}, Max={stats.get('max', 'N/A')}, Mean={stats.get('mean', 'N/A')}, Median={stats.get('median', 'N/A')}\n"
            
            # Add categorical statistics
            if 'categorical_stats' in sheet_summary:
                description += "\nCategorical Statistics:\n"
                for col, stats in sheet_summary['categorical_stats'].items():
                    description += f"- {col}: Unique Values={stats.get('unique_values', 'N/A')}, Most Common={stats.get('most_common', 'N/A')} (Count: {stats.get('most_common_count', 'N/A')})\n"
        
        # Add KPI metrics
        description += "\n\nKPI METRICS:\n"
        for sheet_name, metrics in kpi_metrics.items():
            description += f"\nSheet/Table: {sheet_name}\n"
            for col, metric_data in metrics.items():
                description += f"- {col} (Category: {metric_data.get('category', 'N/A')}): "
                if 'mean' in metric_data:
                    description += f"Mean={metric_data.get('mean', 'N/A')}, "
                if 'median' in metric_data:
                    description += f"Median={metric_data.get('median', 'N/A')}, "
                if 'min' in metric_data:
                    description += f"Min={metric_data.get('min', 'N/A')}, "
                if 'max' in metric_data:
                    description += f"Max={metric_data.get('max', 'N/A')}"
                description += "\n"
        
        # Add correlations
        description += "\n\nCORRELATIONS:\n"
        for sheet_name, sheet_correlations in correlations.items():
            description += f"\nSheet/Table: {sheet_name}\n"
            for col1, col_correlations in sheet_correlations.items():
                for col2, corr_value in col_correlations.items():
                    if abs(corr_value) >= 0.5:  # Only include stronger correlations
                        description += f"- {col1} and {col2}: {corr_value}\n"
        
        # Add trends
        description += "\n\nTRENDS:\n"
        for trend_key, trend_data in trends.items():
            description += f"- {trend_data.get('metric_column', 'Unknown metric')}: "
            description += f"Trend={trend_data.get('trend', 'N/A')}, "
            description += f"Start Value={trend_data.get('start_value', 'N/A')}, "
            description += f"End Value={trend_data.get('end_value', 'N/A')}, "
            description += f"Percent Change={trend_data.get('percent_change', 'N/A')}%\n"
        
        # Add insights
        description += "\n\nINSIGHTS:\n"
        for insight in insights:
            description += f"- {insight.get('type', 'general')}: {insight.get('description', 'N/A')}\n"
        
        return description
    
    def _call_openai_api(self, prompt):
        """
        Call the OpenAI API with a prompt.
        
        Args:
            prompt: Prompt for the API
            
        Returns:
            str: API response text or None if failed
        """
        if not self.api_key:
            logger.error("OpenAI API key not set")
            return None
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        data = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": "You are an expert data analyst and business intelligence specialist. Provide detailed, insightful analysis of data."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.3,  # Lower temperature for more focused, analytical responses
            "max_tokens": 2000
        }
        
        try:
            response = requests.post(self.api_url, headers=headers, json=data)
            response.raise_for_status()
            
            response_data = response.json()
            message_content = response_data['choices'][0]['message']['content']
            
            return message_content
        
        except Exception as e:
            logger.error(f"Error calling OpenAI API: {str(e)}")
            return None


def enhance_analysis_with_openai(analysis_results, api_key, depth="standard"):
    """
    Enhance analysis results with OpenAI insights.
    
    Args:
        analysis_results: Analysis results from DataAnalyzer
        api_key: OpenAI API key
        depth: Analysis depth ("basic", "standard", "advanced")
        
    Returns:
        dict: Enhanced analysis results
    """
    logger.info(f"Enhancing analysis with OpenAI: {analysis_results['file_name']}")
    
    # Create OpenAI analyzer
    analyzer = OpenAIAnalyzer(api_key)
    
    # Analyze data
    enhanced_results = analyzer.analyze_data(analysis_results, depth)
    
    # Save enhanced results
    if enhanced_results:
        # Get base directory
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        results_dir = os.path.join(base_dir, "data", "analysis_results")
        
        # Create a filename for the enhanced results
        file_name = analysis_results['file_name']
        file_name_without_ext = os.path.splitext(file_name)[0]
        results_file = os.path.join(results_dir, f"{file_name_without_ext}_enhanced_analysis.json")
        
        # Save the enhanced results as JSON
        with open(results_file, 'w') as f:
            json.dump(enhanced_results, f, indent=2)
        
        logger.info(f"Enhanced analysis results saved to: {results_file}")
    
    return enhanced_results


if __name__ == "__main__":
    # Example usage
    import sys
    
    if len(sys.argv) > 2:
        analysis_file = sys.argv[1]
        api_key = sys.argv[2]
        
        # Load analysis results
        with open(analysis_file, 'r') as f:
            analysis_results = json.load(f)
        
        # Enhance analysis with OpenAI
        enhanced_results = enhance_analysis_with_openai(analysis_results, api_key)
        
        if enhanced_results:
            print(f"Enhanced analysis completed for {analysis_results['file_name']}")
    else:
        print("Usage: python openai_analyzer.py <analysis_file> <openai_api_key>")
